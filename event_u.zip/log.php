<html>
<body>
<?php
	if ( $_POST ) {
$a=$_POST['ld'];
$b=$_POST['lpd'];
include "config.php";
$r=mysqli_query($conn,"select mid from members where eid='$a' and paswd='$b' ");
while($arr=mysqli_fetch_array($r))
{
	$mid=$arr[0];
}

if(mysqli_num_rows($r)>0)
{	?>
	      <script type="text/javascript">
				alert("Welcome.....");
			</script>
			<?php 
session_start();
$_SESSION["id"] = $mid;


}
	else
{?>
	<script type="text/javascript">
				alert("user id or password is incoreect");
			</script>
			<?php 
}	
	}?>
	
 </body>
</html>