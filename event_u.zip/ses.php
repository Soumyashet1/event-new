<?php 
session_start();
if(isset($_SESSION["id"]))
{
echo "#small-dialog";
}
else
{
echo "#myModal2";
}
?>