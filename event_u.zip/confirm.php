<?php 
include "config.php";
$eid=$_GET['id'];
$n=$_POST['nk'];
session_start();
$mid=$_SESSION["id"];
$r=mysqli_query($conn,"select tprice from eventdetails where eid='$eid'");
while($arr=mysqli_fetch_array($r))
{
	$tprice=$arr[0];
}

$p = $n * $tprice;
echo "$b";
echo "total price=$p<br>";
echo "your tickets has been successfully booked....!";
$sql = mysqli_query($conn,"INSERT INTO bookingdetails (mid,eid,nooft,price) VALUES ($mid,$eid,$n,$p)");
$sql = mysqli_query($conn,"UPDATE eventdetails SET seats=seats-$n where eid=$eid");
?>