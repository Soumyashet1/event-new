<?php 
include "header.php";
?>
	<!-- team -->
	<div id="staff" class="team">  
		<div class="container">  
			<h3 class="w3stitle">OUR <span> Staff</span></h3>  
			<div class="team-agileinfo w3ls-team-row">  
				<div class="col-md-3 col-sm-3 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t1.jpg" alt="img">
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Mark Sophia</h5>
							<p>Manager</p>
						</div>	 
					</div>    
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t2.jpg" alt="img"> 
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Henry Ken</h5>
							<p>Event-Manager</p>
						</div>
					</div>    
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t3.jpg" alt="img"> 
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5> Laura Hill</h5>
							<p>Team Manager</p>
						</div>
					</div>    
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t4.jpg" alt="img"> 
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Edward</h5>
							<p>CEO& Founder</p>
						</div>
					</div>    
				</div>
				<div class="clearfix"> </div> 
			</div>
		</div>
	</div>
	<!-- //team -->  
 
<?php 
include "footer.php";
?>