<?php 
include "header.php";
?>
<div class="container" style="padding-top:100px;">
	<div class="resp-tabs-container">
		<div class="agileits-login">	
		<div class="agileits-login">	
		<ul class="">
								<li class="resp-tab-item" aria-controls="tab_item-0"><span>Login</span></li>
								
							</ul>
			<form action="index.php" method="post">
				<input type="text" class="email" name="ld" placeholder="Email" required=""/>
				<input type="password" class="password" name="lpd" placeholder="Password" required=""/>
				<div class="wthree-text"> 
				<ul> 
				<li><label class="anim"><input type="checkbox" class="checkbox"><span> Remember me ?</span></label></li>
				<li> <a href="#">Forgot password?</a> </li>
				</ul>
				<div class="clearfix"> </div>
				</div>  
				<div class="w3ls-submit"> 
				<input type="submit" value="LOGIN">  	
				</div>	
			</form>
			<form action="p.php" method="post">
				<span>Login</span>
			<input type="text" name="fname" placeholder="First name" required="">
			<input type="text" name="lname" placeholder="Last name" required="">
			<input type="text" name="uname" placeholder="User name" required="">
			<input type="text" class="email" name="emailid" placeholder="Email-id" required=""/>
			<input type="text" name="numb" placeholder="contact number" required="">
			<textarea name="add" placeholder="Address" required=""></textarea>
			<input type="password" class="password" name="Password" placeholder="Password" required=""/>	
			<input type="password" class="password" name="Password1" placeholder="Password" required=""/>	
			<label class="anim">
			<input type="checkbox" class="checkbox">
			<span> I accept the terms of use</span> 
			</label> 
			<div class="w3ls-submit"> 
			<input class="register" type="submit" value="REGISTER">  
			</div>
			</form>			
</div>	
</div>	
</div>