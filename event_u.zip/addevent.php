<?php 
include "header.php";
?>
<div class="container" style="padding-top:100px;">
	<div class="resp-tabs-container">
		<div class="agileits-login">
		<form action="p1.php" method="post" enctype="multipart/form-data" >
			Event name:<input type="text" name="ename" placeholder="Event name" required=""><br>
			organizer name:<input type="text" name="eorg" placeholder="organizer name" required=""><br>
			Description:<textarea name="desc" placeholder="Event name" required=""></textarea><br>
			venue:<input type="text" name="venue" placeholder="venue" required=""><br>
			Event start date:<input type="text" name="estartd" placeholder="Event start date" required=""><br>
			Event end date:<input type="text" name="eendd" placeholder="Event end date" required=""><br>
			Event url:<input type="text" name="eurl" placeholder="Event url" required=""><br>
			Ticket price:<input type="text" name="tprice" placeholder="Ticket price" required=""><br>
			contact number 1:<input type="text" name="cno1" placeholder="contact number 1" required=""><br>
			contact number 2:<input type="text" name="cno2" placeholder="contact number 2" required=""><br>
			contact number 3:<input type="text" name="cno3" placeholder="contact number 3" required=""><br>
			total seats:<input type="number" name="seats" placeholder="total seats" required=""><br>
			Terms and conditions:<input type="text" name="terms" placeholder="Terms and conditions" required=""><br> 
			Booking url:<input type="text" name="bookurl" placeholder="Booking url" required=""><br>
			Image:<input  type="file" name="image" required=""><br>
			<div class="w3ls-submit"><input class="register" type="submit" value="book"></div>	
		</form>
</div>	
</div>	
</div>	