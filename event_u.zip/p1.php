<?php
include "config.php";
$ename = $_POST['ename'];
$eorg = $_POST['eorg'];
$desc = $_POST['desc'];
$venue = $_POST['venue'];
$estartd = $_POST['estartd'];
$eendd = $_POST['eendd'];
$eurl = $_POST['eurl'];
$tprice = $_POST['tprice'];
$cno1 = $_POST['cno1'];
$cno2 = $_POST['cno2'];
$cno3 = $_POST['cno3'];
$seats = $_POST['seats'];
$terms = $_POST['terms'];
$bookurl = $_POST['bookurl'];
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $a=rand(0,999);
	  $path="/var/www/html/hw/event_u/images/";
      $filen="$a"."_"."$file_name";
      chmod($path,0777);
      move_uploaded_file($file_tmp,$path.$filen);
      $f="images/"."$filen";
   echo $f;

$sql = mysqli_query($conn,"INSERT INTO eventdetails (ename,eorg,description,venue,estartd,eendd,eurl,tprice,cno1,cno2,cno3,seats,terms,bookurl,eimage) VALUES ('$ename','$eorg','$desc','$venue','$estartd','$eendd','$eurl','$tprice','$cno1','$cno2','$cno3','$seats','$terms','$bookurl','$f')");

$r=mysqli_query($conn,"select * from eventdetails");
print"<table border=4 align=center id=ddata>
	<tr>
	<th>MID</th>
	<th>FNAME</th>
	<th>LNAME</th>
	<th>UNAME</td>
	<th>EID</th>
	<th>PHONE_NUMBER</th>
	<th>ADDRESS</th>
	<th>PASSWORD</th>
	<th>STATUS</th>
	<th>MID</th>
	<th>FNAME</th>
	<th>LNAME</th>
	<th>UNAME</td>
	<th>EID</th>
	<th>PHONE_NUMBER</th>


	</tr>";
while($arr=mysqli_fetch_array($r))
{
 print"<tr>
       <td>$arr[0]</td>
       <td>$arr[1]</td>
       <td>$arr[2]</td>
	   <td>$arr[3]</td>
	   <td>$arr[4]</td>
	   <td>$arr[5]</td>
	   <td>$arr[6]</td>
	   <td>$arr[7]</td>
	   <td>$arr[9]</td>
	   <td>$arr[10]</td>
	   <td>$arr[11]</td>
	   <td>$arr[12]</td>
	   <td>$arr[13]</td>
	   <td>$arr[14]</td>
	   <td>$arr[15]</td>
	   </tr>";
}	   
print "</table>";
?>
