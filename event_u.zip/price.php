<?php 
include "header.php";
?>
	<!-- prices -->
	<div id="prices" class="prices w3-agilefireworks jarallax">
		<div class="pricesw3-agileits">
			<div class="container"> 
				<h3 class="w3stitle w3stitle1">Our <span> Prices</span></h3>  
				<div class="prices-agileinfo">
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-two">
							<div class="pricing-top top-two">
								<h3>Classic</h3>
								<p>$50</p>
							</div>
							<div class="pricing-bottom"> 
								<p>Code Dress</p> 
								<p>Dance Troupe</p> 
								<p>-</p> 
								<p>Fireworks</p> 
								<p class="w3agile">Live Band</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">Book Now</a>
								</div>
							</div>
						</div>  
					</div>
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing">
							<div class="pricing-top">
								<h3>Elite</h3>
								<p>$62</p>
							</div>
							<div class="pricing-bottom"> 
								<p>Code Dress</p> 
								<p>Premium Buffet</p> 
								<p>Fireworks</p> 
								<p>Dance Troupe</p> 
								<p>Rain Dance</p>  
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">Book Now</a>
								</div>
							</div>
						</div>  
					</div>
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-three">
							<div class="pricing-top top-three">
								<h3>Couple</h3>
								<p>$80</p>
							</div>
							<div class="pricing-bottom wthree"> 
								<p>Code Dress</p> 
								<p>Lavish Buffet</p> 
								<p>Fireworks</p> 
								<p>Dance Troupe</p> 
								<p>Rain Dance</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">Book Now</a>
								</div>
							</div>
						</div>  
					</div> 
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-four">
							<div class="pricing-top top-four">
								<h3>Special</h3>
								<p>$100</p>
							</div>
							<div class="pricing-bottom w3ls"> 
								<p>Code Dress</p> 
								<p>Lavish Buffet</p>  
								<p>Fireworks</p> 
								<p class="w3agile agileits">Rain Dance</p>  
								<p>Dance Troupe</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">Book Now</a>
								</div>
							</div>
						</div>  
					</div> 
					<div class="clearfix"> </div>  
				</div> 
			</div> 
		</div>
	</div>
	<!-- //prices -->
 
<?php 
include "footer.php";
?>