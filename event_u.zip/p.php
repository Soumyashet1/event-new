<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$emailid=$_POST['emailid'];
$numb=$_POST['numb'];
$add=$_POST['add'];
$paswd=$_POST['Password'];
include "config.php";
$sql = mysqli_query($conn,"INSERT INTO members (fnam,lnam,unam,eid,pno,address,paswd,status) VALUES ('$fname','$lname','$uname','$emailid','$numb','$add','$paswd','1')");

$r=mysqli_query($conn,"select * from members");
print"<table border=4 align=center id=ddata>
	<tr>
	<th>MID</th>
	<th>FNAME</th>
	<th>LNAME</th>
	<th>UNAME</td>
	<th>EID</th>
	<th>PHONE_NUMBER</th>
	<th>ADDRESS</th>
	<th>PASSWORD</th>
	<th>STATUS</th>

	</tr>";
while($arr=mysqli_fetch_array($r))
{
 print"<tr>
       <td>$arr[0]</td>
       <td>$arr[1]</td>
       <td>$arr[2]</td>
	   <td>$arr[3]</td>
	   <td>$arr[4]</td>
	   <td>$arr[5]</td>
	   <td>$arr[6]</td>
	   <td>$arr[7]</td>
	   <td>$arr[8]</td>
	   
</tr>";
}	   
print "</table>";
?>

