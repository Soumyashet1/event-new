<?php
echo "your tickets are successfully booked";
$db=mysql_connect("localhost","root");
$r=mysql_select_db("eventmngt");
$r=mysql_query("select tprice from eventdetails where eid='$eid'");
?>